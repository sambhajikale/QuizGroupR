package mainclasses;

import Product.SelectProduct;

public class BlankClass {

	public static void main(String[] args) {
		
		exit();
		
	}
	public static void exit()
	{
		System.out.println(".......Have a Nice Day......");
		System.out.println("......Program Exit.....Run Again or Restart Program");
	}
}
